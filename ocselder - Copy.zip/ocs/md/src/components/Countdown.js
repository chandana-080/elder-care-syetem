import React, { useEffect, useState } from 'react';
import './styles.css'; // Import your CSS styles
import { useNavigate } from 'react-router-dom';

const months = [
  "January", "February", "March", "April", "May", "June", 
  "July", "August", "September", "October", "November", "December",
];
const weekdays = [
  "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday",
];

function Countdown() {
  const [countdownValues, setCountdownValues] = useState({
    days: '30',
    hours: '24',
    minutes: '60',
    seconds: '60',
  });
let navigate=useNavigate();
  useEffect(() => {
    const futureDate = new Date(); // Initialize with the current date
    futureDate.setDate(futureDate.getDate() + 7); // Add 7 days for example (adjust as needed)
    futureDate.setHours(15, 30, 0); // Set the future time (adjust as needed)

    const futureTime = futureDate.getTime();

    const countdown = setInterval(() => {
      const today = new Date().getTime();
      const t = futureTime - today;

      if (t <= 0) {
        clearInterval(countdown);
        setCountdownValues({
          days: '00',
          hours: '00',
          minutes: '00',
          seconds: '00',
        });
      } else {
        const oneDay = 24 * 60 * 60 * 1000;
        const oneHour = 60 * 60 * 1000;
        const oneMinute = 60 * 1000;
        let days = Math.floor(t / oneDay);
        let hours = Math.floor((t % oneDay) / oneHour);
        let minutes = Math.floor((t % oneHour) / oneMinute);
        let seconds = Math.floor((t % oneMinute) / 1000);

        days = format(days);
        hours = format(hours);
        minutes = format(minutes);
        seconds = format(seconds);

        setCountdownValues({
          days,
          hours,
          minutes,
          seconds,
        });
      }
    }, 1000);

    return () => clearInterval(countdown);
  }, []);

  const format = (item) => {
    if (item < 10) {
      return `0${item}`;
    }
    return item;
  };

let register=()=>{
  navigate('/Register');
}
  return (
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>countdown</title>
        <link rel="stylesheet" href="styles.css" />
        <style>
          {`
           
            a.button {
              display: inline-block;
              padding: 10px 20px;
              text-decoration: none;
              background-color: #007bff;
              color: #fff;
              border-radius: 4px;
              transition: background-color 0.3s ease;
            }
    
            a.button:hover {
              background-color: #0056b3;
            }
          `}
        </style>
      </head>
      <body>
        <section className="section-center">
          <article className="gift-img">
            <img src="https://www.schwabeindia.com/wp-content/uploads/2023/05/Schwabe-blog-banner-The-Role-of-Homeopathy-in-Indias-Healthcare-System.jpg" alt="gift picture" className="center-image" />
          </article>
          <article className="gift-info">
            <h3>Elderly care system</h3>
            <h4 className="giveaway">
              reminder of medicines
            </h4>
            <a href="./Register.js" className="button" onClick={register}>Add medicine</a>
            <div className="deadline">
              {Object.entries(countdownValues).map(([key, value]) => (
                <div className="deadline-format" key={key}>
                  <div>
                    <h4 className={key}>{value}</h4>
                    <span>{key.toUpperCase()}</span>
                  </div>
                </div>
              ))}
            </div>
          </article>
        </section>
        <script src="app.js"></script>
      </body>
    </html>
  );
}

export default Countdown;







/*import React, { useEffect, useState } from 'react';
import './styles.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

  
  function Countdown() {
    const [countdownValues, setCountdownValues] = useState({
      days: '00',
      hours: '00',
      minutes: '00',
      seconds: '00',
    });
    const [times, setTimes] = useState([]);
    let navigate = useNavigate(); 
    
    
    useEffect(() => {
      axios.get('/get-user')
        .then((response) => {
          const fetchedTimes = response.data;
          setTimes(fetchedTimes);
        })
        .catch((error) => {
          console.error('Error fetching times:', error);
        });
    }, []);
  
    useEffect(() => {
      let countdownInterval;
  
      if (times.length > 0) {
        const updateCountdown = () => {
          const currentTime = new Date().getTime();
          const futureTime = new Date(times[0]).getTime(); // Assuming the first time is the target date
  
          const timeDifference = futureTime - currentTime;
  
          if (timeDifference <= 0) {
            clearInterval(countdownInterval);
            // Handle the logic for the countdown reaching zero
  
            // For example:
            setTimeout(() => {
              // Reset or move to the next date logic here
            }, 30000); // Display message for 30 seconds
          } else {
            const oneDay = 24 * 60 * 60 * 1000;
            const oneHour = 60 * 60 * 1000;
            const oneMinute = 60 * 1000;
  
            let days = Math.floor(timeDifference / oneDay);
            let hours = Math.floor((timeDifference % oneDay) / oneHour);
            let minutes = Math.floor((timeDifference % oneHour) / oneMinute);
            let seconds = Math.floor((timeDifference % oneMinute) / 1000);
  
            days = days.toString().padStart(2, '0');
            hours = hours.toString().padStart(2, '0');
            minutes = minutes.toString().padStart(2, '0');
            seconds = seconds.toString().padStart(2, '0');
  
            setCountdownValues({ days, hours, minutes, seconds });
          }
        };
  
        updateCountdown();
        countdownInterval = setInterval(updateCountdown, 1000);
  
        return () => clearInterval(countdownInterval);
      }
    }, [times]);






  const register = () => {
    navigate('/Register');
  };













  return (
    <html lang="en">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>countdown</title>
        <link rel="stylesheet" href="styles.css" />
        <style>
          {`
           
            a.button {
              display: inline-block;
              padding: 10px 20px;
              text-decoration: none;
              background-color: #007bff;
              color: #fff;
              border-radius: 4px;
              transition: background-color 0.3s ease;
            }
    
            a.button:hover {
              background-color: #0056b3;
            }
          `}
        </style>
      </head>
      <body>
        <section className="section-center">
          <article className="gift-img">
            <img src="https://www.schwabeindia.com/wp-content/uploads/2023/05/Schwabe-blog-banner-The-Role-of-Homeopathy-in-Indias-Healthcare-System.jpg" alt="gift picture" className="center-image" />
          </article>
          <article className="gift-info">
            <h3>Elderly care system</h3>
            <h4 className="giveaway">
              reminder of medicines
            </h4>
            <a href="./Register.js" className="button" onClick={register}>Add medicine</a>
            <div className="deadline">
              {Object.entries(countdownValues).map(([key, value]) => (
                <div className="deadline-format" key={key}>
                  <div>
                    <h4 className={key}>{value}</h4>
                    <span>{key.toUpperCase()}</span>
                  </div>
                </div>
              ))}
            </div>
          </article>
        </section>
        <script src="app.js"></script>
      </body>
    </html>
  );
}

  
export default Countdown;*/
