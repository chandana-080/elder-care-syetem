import React ,{useContext, useEffect}from 'react'
import { Outlet , NavLink} from 'react-router-dom';
import './Rootlayout.css';


function Rootlayout() {
    
  
 
  
  return (
    <div>
        
     <ul className="nav d-flex flex-row justify-content-center  bg-dark p-2 navbar ">
  
     
            
            <li className="nav-item">
              <NavLink className="nav-link text-light" to="/Register">
                Register
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link text-light" to="/">
                Countdown
              </NavLink>
            </li>
  
</ul>
<div className="outlet-container">
    <Outlet/>
    </div>

    </div>
  )
}

export default Rootlayout
