import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Register() {
    const { register, handleSubmit, formState: { errors } } = useForm();

    const [medicines, setMedicines] = useState([{ medicine: '', phoneNumber: '', times: [''] }]);
    const [msg, setMsg] = useState('');
    const [err, setErr] = useState('');
    const navigate = useNavigate();

    const handleMedicineChange = (index, field, value) => {
        const updatedMedicines = [...medicines];
        updatedMedicines[index][field] = value;
        setMedicines(updatedMedicines);
    };

    const addMedicineEntry = () => {
        if (medicines.every(entry => entry.medicine !== '' && entry.phoneNumber !== '')) {
            setMedicines([...medicines, { medicine: '', phoneNumber: '', times: [''] }]);
        } else {
            setErr('Please fill in all required fields before adding a new entry.');
        }
    };

    const removeMedicineEntry = (index) => {
        const updatedMedicines = medicines.filter((_, i) => i !== index);
        setMedicines(updatedMedicines);
    };
    




      /*const onSubmit = () => {
        const formattedData = medicines.map(({ medicine, phoneNumber, times }) => ({
            medicine,
            phoneNumber,
            times: times.filter(time => time !== '') // Remove empty time slots if any
        }));
    
        axios.post('http://localhost:3500/user-api/create-user', formattedData)
            .then((response) => {
                console.log(response);
                if (response.status === 201) {
                    setMsg('Data stored');
                    // Redirect or perform any other action upon successful data storage
                    // navigate('/success'); // Example redirection using react-router-dom
                } else {
                    setErr(response.data.message || 'Failed to store data');
                }
            })
            .catch((err) => {
                console.error('Error:', err);
                setErr(err.message || 'An error occurred');
            });
    };*/
    
    const onSubmit = () => {
        const formattedData = medicines.map(({ medicine, phoneNumber, times }) => ({
            medicine,
            phoneNumber,
            times: times.filter(time => time !== '') // Remove empty time slots if any
        }))[0]; // Take the first item from the mapped array to convert it into an object
    
        // Convert the array into an object and log it
        console.log('Formatted Object:', formattedData);
    
        axios.post('http://localhost:3500/user-api/create-user', formattedData)
            .then((response) => {
                console.log(response);
                if (response.status === 201) {
                    setMsg('Data stored');
                    // Redirect or perform any other action upon successful data storage
                    // navigate('/success'); // Example redirection using react-router-dom
                } else {
                    setErr(response.data.message || 'Failed to store data');
                }
            })
            .catch((err) => {
                console.error('Error:', err);
                setErr(err.message || 'An error occurred');
            });
    };
    

    





    
    

    return (
        <div className='register-background'>
            <form onSubmit={handleSubmit(onSubmit)}>
                <div className='container'>

                {medicines.map((medicineEntry, index) => (
    <div className='row' key={index}>
        <div className='col'>
            <label htmlFor={`medicine-${index}`}>Medicine</label>
            <input
                type='text'
                className='form-control'
                id={`medicine-${index}`}
                {...register(`medicine-${index}`, { required: true })}
                value={medicineEntry.medicine}
                onChange={(e) => handleMedicineChange(index, 'medicine', e.target.value)}
            />
            {errors[`medicine-${index}`]?.type === 'required' && (
                <p className='text-danger'>*Medicine is required</p>
            )}
        </div>

                            <div className='col'>
            <label htmlFor={`phone-${index}`}>Phone Number</label>
            <input
                type='tel'
                className='form-control'
                id={`phone-${index}`}
                {...register(`phone-${index}`, { required: true })}
                value={medicineEntry.phoneNumber}
                onChange={(e) => handleMedicineChange(index, 'phoneNumber', e.target.value)}
            />
            {errors[`phone-${index}`]?.type === 'required' && (
                <p className='text-danger'>*Phone Number is required</p>
            )}
        </div>



                            <div className='col'>
                                <label>Times</label>
                                {medicineEntry.times.map((time, timeIndex) => (
                                    <div key={timeIndex}>
                                        <input
                                            type='time'
                                            className='form-control'
                                            value={time}
                                            onChange={(e) => {
                                                const newMedicines = [...medicines];
                                                newMedicines[index].times[timeIndex] = e.target.value;
                                                setMedicines(newMedicines);
                                            }}
                                        />
                                    </div>
                                ))}
                                <button
                                    type='button'
                                    onClick={() => {
                                        const newMedicines = [...medicines];
                                        newMedicines[index].times.push('');
                                        setMedicines(newMedicines);
                                    }}
                                >
                                    Add Time
                                </button>
                            </div>
                            <div className='col'>
                                {index > 0 && (
                                    <button type='button' onClick={() => removeMedicineEntry(index)}>Remove</button>
                                )}
                            </div>
                        </div>
                        ))}
                        </div>
                        <button type='button' onClick={addMedicineEntry}>Add Medicine</button>






                <button type='submit' className='btn btn-success fs-5 mt-3 d-block float-end'>
                    Submit
                </button>
            </form>
        </div>
    );
}

export default Register;
