import React from 'react';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import './App.css';
import Register from './components/Register';
import Rootlayout from './components/Rootlayout';
import Countdown from './components/Countdown';

function App() {
  const router = createBrowserRouter([
    {
      path: '/',
      element: <Rootlayout />,
      children: [
       {
        path:"/",
        element:<Countdown/>
       },
        { path: '/Register',
         element: <Register /> },
       
      ],
    },
  ]);

  return (
    <div className="App">
        
     <RouterProvider router={router}/>
   
    </div>
  );
}

export default App;
