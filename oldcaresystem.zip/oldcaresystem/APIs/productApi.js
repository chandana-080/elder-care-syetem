const exp=require("express")
const productApp=exp.Router()
const expressAsyncHandler=require('express-async-handler')

module.exports=productApp 